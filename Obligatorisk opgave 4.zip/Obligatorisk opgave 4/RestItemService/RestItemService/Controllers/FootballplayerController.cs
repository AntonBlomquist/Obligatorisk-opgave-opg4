﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using RestItemService.Models;
using RestItemService.Managers;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace RestItemService.Controllers {
    [Route("api/[controller]")]
    [ApiController]
    public class FootballplayerController : ControllerBase {
        private readonly IManageItems mgr = new ManageItems();

        // GET: api/<FootballplayerController>
        [HttpGet]
        public IEnumerable<Footballplayer> Get() {
            return mgr.Get();
        }

        // GET api/<FootballplayerController>/5
        [HttpGet("{id}")]
        public Footballplayer Get(int id) {
            return mgr.Get(id);
        }

        // POST api/<FootballplayerController>
        [HttpPost]
        public bool Post([FromBody] Footballplayer value) {
            return mgr.Create(value);
        }

        // PUT api/<FootballplayerController>/5
        [HttpPut("{id}")]
        public bool Put(int id, [FromBody] Footballplayer value) {
            return mgr.Update(id, value);
        }

        // DELETE api/<FootballplayerController>/5
        [HttpDelete("{id}")]
        public Footballplayer Delete(int id) {
            return mgr.Delete(id);
        }
    }
}
