﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using RestItemService.Models;

namespace RestItemService.Managers {
    public interface IManageItems {
        public IEnumerable<Footballplayer> Get();
        public Footballplayer Get(int id);
        public bool Create(Footballplayer value);
        public bool Update(int id, Footballplayer value);
        public Footballplayer Delete(int id);

    }
}
