﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using RestItemService.Models;

namespace RestItemService.Managers {
    public class ManageItems : IManageItems {

        private static readonly List<Footballplayer> players = new List<Footballplayer>() {
            new Footballplayer("anotn", 10, 10),
            new Footballplayer("Lols", 20, 20),
            new Footballplayer("ZlatiFarti", 30, 30)

        };
        public IEnumerable<Footballplayer> Get() {
            return new List<Footballplayer>(players);
        }
        public Footballplayer Get(int id) {
            return players.Find(p => p.Id == id);
        }
        public bool Create(Footballplayer value) {
            players.Add(value);
            return true;
        }
        public bool Update(int id, Footballplayer value) {
            Footballplayer player = Get(id);
            if(player!=null) {
                player = value;
                return true;
            }
            return false;
        }
        public Footballplayer Delete(int id) {
            Footballplayer player = Get(id);
            players.Remove(player);
            return player;
        }
    }
}
